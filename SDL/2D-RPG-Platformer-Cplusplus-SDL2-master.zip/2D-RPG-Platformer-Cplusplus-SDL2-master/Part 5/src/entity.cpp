#include "Entity.hpp"
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>

Entity::Entity(double p_x, double p_y, SDL_Texture* p_tex)
{
	
}
