# 2D-RPG-Platformer-Cplusplus-SDL2
An open source 2D RPG written in C++ and SDL2. This is mainly for my youtube followers, but you're more than welcome to grab the code a make a break for it, just be sure to disable the dart traps and avoid the hidden spike pits, you code-pirate. I use sublime text for my projects, which is what the Windows.sublime-project and Linux.sublime-project is all about. 
You'll need to setup mingw64 if your on Windows, and if you're on Linux just a quick 

sudo apt-get install g++ 

should be fine. You'll also have to setup SDL, so I recommend you check out my Youtube channel called codergopher. It will show you how to do just that, and who knows, you might even have a bit of fun, eh?

Once the project is more completed, I'll start including prebuilt Windows and Linux binaries for the game, just for people who only want to play it. Until then, you'll have to compile it yourself.
